package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AudioFxState
import com.example.model.EqBand
import com.example.model.Preset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "fx_sound_preferences")

class PreferencesManager(private val context: Context) {

    private object Keys {
        val POWER_ON = booleanPreferencesKey("power_on")
        val MASTER_GAIN = floatPreferencesKey("master_gain")
        val BASS_STRENGTH = floatPreferencesKey("bass_strength")
        val CLARITY_STRENGTH = floatPreferencesKey("clarity_strength")
        val VOICE_STRENGTH = floatPreferencesKey("voice_strength")
        val SURROUND_STRENGTH = floatPreferencesKey("surround_strength")
        val SELECTED_PRESET = stringPreferencesKey("selected_preset")
        val IS_CUSTOM = booleanPreferencesKey("is_custom")
        val AUTO_HEADROOM = booleanPreferencesKey("auto_headroom")
        val BG_SERVICE_ENABLED = booleanPreferencesKey("bg_service_enabled")
        val CUSTOM_PRESETS_JSON = stringPreferencesKey("custom_presets_json")

        fun bandKey(index: Int) = floatPreferencesKey("eq_band_$index")
    }

    val audioFxStateFlow: Flow<AudioFxState> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { prefs ->
            val powerOn = prefs[Keys.POWER_ON] ?: true
            val masterGain = prefs[Keys.MASTER_GAIN] ?: 0f
            val bass = prefs[Keys.BASS_STRENGTH] ?: 0f
            val clarity = prefs[Keys.CLARITY_STRENGTH] ?: 0f
            val voice = prefs[Keys.VOICE_STRENGTH] ?: 0f
            val surround = prefs[Keys.SURROUND_STRENGTH] ?: 0f
            val presetName = prefs[Keys.SELECTED_PRESET] ?: "Flat"
            val isCustom = prefs[Keys.IS_CUSTOM] ?: false
            val autoHeadroom = prefs[Keys.AUTO_HEADROOM] ?: true

            val defaultBands = EqBand.createDefaultBands()
            val bands = defaultBands.map { defaultBand ->
                val savedGain = prefs[Keys.bandKey(defaultBand.index)] ?: defaultBand.gainDb
                defaultBand.copy(gainDb = savedGain)
            }

            AudioFxState(
                isPowerOn = powerOn,
                bands = bands,
                masterGainDb = masterGain,
                bassStrength = bass,
                clarityStrength = clarity,
                voiceStrength = voice,
                surroundStrength = surround,
                selectedPresetName = presetName,
                isCustomModified = isCustom,
                autoHeadroomEnabled = autoHeadroom
            )
        }

    val isBackgroundServiceEnabled: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { prefs -> prefs[Keys.BG_SERVICE_ENABLED] ?: true }

    val customPresetsFlow: Flow<List<Preset>> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { prefs ->
            val jsonString = prefs[Keys.CUSTOM_PRESETS_JSON] ?: "[]"
            parseCustomPresets(jsonString)
        }

    suspend fun saveAudioFxState(state: AudioFxState) {
        context.dataStore.edit { prefs ->
            prefs[Keys.POWER_ON] = state.isPowerOn
            prefs[Keys.MASTER_GAIN] = state.masterGainDb
            prefs[Keys.BASS_STRENGTH] = state.bassStrength
            prefs[Keys.CLARITY_STRENGTH] = state.clarityStrength
            prefs[Keys.VOICE_STRENGTH] = state.voiceStrength
            prefs[Keys.SURROUND_STRENGTH] = state.surroundStrength
            prefs[Keys.SELECTED_PRESET] = state.selectedPresetName
            prefs[Keys.IS_CUSTOM] = state.isCustomModified
            prefs[Keys.AUTO_HEADROOM] = state.autoHeadroomEnabled

            state.bands.forEach { band ->
                prefs[Keys.bandKey(band.index)] = band.gainDb
            }
        }
    }

    suspend fun setPowerOn(powerOn: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.POWER_ON] = powerOn
        }
    }

    suspend fun setBackgroundServiceEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.BG_SERVICE_ENABLED] = enabled
        }
    }

    suspend fun setAutoHeadroom(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.AUTO_HEADROOM] = enabled
        }
    }

    suspend fun saveCustomPreset(preset: Preset, currentList: List<Preset>) {
        val updated = currentList.filterNot { it.name.equals(preset.name, ignoreCase = true) } + preset
        val json = serializeCustomPresets(updated)
        context.dataStore.edit { prefs ->
            prefs[Keys.CUSTOM_PRESETS_JSON] = json
        }
    }

    suspend fun deleteCustomPreset(presetName: String, currentList: List<Preset>) {
        val updated = currentList.filterNot { it.name.equals(presetName, ignoreCase = true) }
        val json = serializeCustomPresets(updated)
        context.dataStore.edit { prefs ->
            prefs[Keys.CUSTOM_PRESETS_JSON] = json
        }
    }

    suspend fun resetToDefaults() {
        context.dataStore.edit { prefs ->
            prefs[Keys.POWER_ON] = true
            prefs[Keys.MASTER_GAIN] = 0f
            prefs[Keys.BASS_STRENGTH] = 0f
            prefs[Keys.CLARITY_STRENGTH] = 0f
            prefs[Keys.VOICE_STRENGTH] = 0f
            prefs[Keys.SURROUND_STRENGTH] = 0f
            prefs[Keys.SELECTED_PRESET] = "Flat"
            prefs[Keys.IS_CUSTOM] = false
            prefs[Keys.AUTO_HEADROOM] = true

            EqBand.createDefaultBands().forEach { band ->
                prefs[Keys.bandKey(band.index)] = 0f
            }
        }
    }

    private fun serializeCustomPresets(presets: List<Preset>): String {
        val array = JSONArray()
        for (p in presets) {
            val obj = JSONObject()
            obj.put("name", p.name)
            obj.put("isBuiltIn", false)
            val gainsArr = JSONArray()
            p.gains.forEach { gainsArr.put(it.toDouble()) }
            obj.put("gains", gainsArr)
            obj.put("masterGainDb", p.masterGainDb.toDouble())
            obj.put("bassStrength", p.bassStrength.toDouble())
            obj.put("clarityStrength", p.clarityStrength.toDouble())
            obj.put("voiceStrength", p.voiceStrength.toDouble())
            obj.put("surroundStrength", p.surroundStrength.toDouble())
            array.put(obj)
        }
        return array.toString()
    }

    private fun parseCustomPresets(jsonString: String): List<Preset> {
        return try {
            val array = JSONArray(jsonString)
            val list = mutableListOf<Preset>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val name = obj.getString("name")
                val gainsArr = obj.getJSONArray("gains")
                val gains = mutableListOf<Float>()
                for (j in 0 until gainsArr.length()) {
                    gains.add(gainsArr.getDouble(j).toFloat())
                }
                while (gains.size < 20) gains.add(0f)
                val master = obj.optDouble("masterGainDb", 0.0).toFloat()
                val bass = obj.optDouble("bassStrength", 0.0).toFloat()
                val clarity = obj.optDouble("clarityStrength", 0.0).toFloat()
                val voice = obj.optDouble("voiceStrength", 0.0).toFloat()
                val surround = obj.optDouble("surroundStrength", 0.0).toFloat()
                list.add(
                    Preset(
                        name = name,
                        isBuiltIn = false,
                        gains = gains.take(20),
                        masterGainDb = master,
                        bassStrength = bass,
                        clarityStrength = clarity,
                        voiceStrength = voice,
                        surroundStrength = surround
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }
}
