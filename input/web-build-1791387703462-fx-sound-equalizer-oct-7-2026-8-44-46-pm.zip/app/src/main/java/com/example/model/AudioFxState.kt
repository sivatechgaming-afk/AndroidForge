package com.example.model

/**
 * Immutable state of all audio processing controls.
 */
data class AudioFxState(
    val isPowerOn: Boolean = true,
    val bands: List<EqBand> = EqBand.createDefaultBands(),
    val masterGainDb: Float = 0f,          // Range -12 dB to +12 dB
    val bassStrength: Float = 0f,           // 0% to 100%
    val clarityStrength: Float = 0f,        // 0% to 100%
    val voiceStrength: Float = 0f,          // 0% to 100%
    val surroundStrength: Float = 0f,       // 0% to 100%
    val selectedPresetName: String = "Flat",
    val isCustomModified: Boolean = false,
    val autoHeadroomEnabled: Boolean = true,
    val activeSessionId: Int = 0,
    val sessionPackageName: String? = null
) {
    /**
     * Estimated peak gain in dB from EQ and master gain to determine potential clipping.
     */
    val estimatedPeakGainDb: Float
        get() {
            val maxBandGain = bands.maxOfOrNull { it.gainDb } ?: 0f
            val bassBoostEquiv = (bassStrength / 100f) * 6f
            val clarityEquiv = (clarityStrength / 100f) * 5f
            val voiceEquiv = (voiceStrength / 100f) * 4f
            val maxEffect = maxOf(bassBoostEquiv, clarityEquiv, voiceEquiv)
            return maxBandGain + masterGainDb + maxEffect
        }

    val isClippingWarning: Boolean
        get() = isPowerOn && estimatedPeakGainDb > 9.0f
}
