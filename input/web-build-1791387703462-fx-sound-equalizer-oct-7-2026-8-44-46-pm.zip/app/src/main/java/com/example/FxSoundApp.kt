package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.service.AudioEffectService

class FxSoundApp : Application() {

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                AudioEffectService.CHANNEL_ID,
                "FX Sound Equalizer Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps audio effects active in the background"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }
}
