package com.example.viewmodel

import android.app.Application
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioEffectEngine
import com.example.audio.DemoAudioPlayer
import com.example.audio.DemoTrack
import com.example.data.PreferencesManager
import com.example.model.AudioFxState
import com.example.model.EqBand
import com.example.model.HardwareFxInfo
import com.example.model.Preset
import com.example.service.AudioEffectService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EqualizerViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = PreferencesManager(application)
    private val engine = AudioEffectEngine.instance
    private val demoPlayer = DemoAudioPlayer.instance

    private val _uiState = MutableStateFlow(AudioFxState())
    val uiState: StateFlow<AudioFxState> = _uiState.asStateFlow()

    val hardwareInfo: StateFlow<HardwareFxInfo> = engine.hardwareInfo

    val isBackgroundServiceEnabled: StateFlow<Boolean> = prefs.isBackgroundServiceEnabled
        .stateIn(viewModelScope, SharingStarted.Lazily, true)

    val isPlayingDemo: StateFlow<Boolean> = demoPlayer.isPlaying
    val currentDemoTrack: StateFlow<DemoTrack> = demoPlayer.currentTrack

    val allPresets: StateFlow<List<Preset>> = combine(
        MutableStateFlow(Preset.DEFAULT_PRESETS),
        prefs.customPresetsFlow
    ) { defaults, customs ->
        defaults + customs
    }.stateIn(viewModelScope, SharingStarted.Lazily, Preset.DEFAULT_PRESETS)

    private var saveJob: Job? = null

    init {
        viewModelScope.launch {
            // Load saved state from DataStore initially
            val initial = prefs.audioFxStateFlow.first()
            _uiState.value = initial

            // Attach to global audio session 0 initially
            engine.attachToSession(0)
            engine.applyState(initial)

            // Start foreground service if enabled
            if (isBackgroundServiceEnabled.value) {
                AudioEffectService.startService(
                    getApplication(),
                    initial.selectedPresetName,
                    initial.isPowerOn
                )
            }
        }
    }

    private fun updateState(newState: AudioFxState) {
        _uiState.value = newState
        // Apply to native audio effect engine in real time
        engine.applyState(newState)

        // Update foreground service notification
        AudioEffectService.updateNotification(
            getApplication(),
            newState.selectedPresetName,
            newState.isPowerOn
        )

        // Debounce persistence to DataStore to avoid excessive disk I/O on 60fps slider drags
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(250)
            prefs.saveAudioFxState(newState)
        }
    }

    fun togglePower() {
        val current = _uiState.value
        val newPower = !current.isPowerOn
        val updated = current.copy(isPowerOn = newPower)
        updateState(updated)
    }

    fun setBandGain(bandIndex: Int, gainDb: Float) {
        val current = _uiState.value
        val clampedGain = gainDb.coerceIn(EqBand.MIN_GAIN_DB, EqBand.MAX_GAIN_DB)
        val updatedBands = current.bands.toMutableList()
        if (bandIndex in updatedBands.indices) {
            updatedBands[bandIndex] = updatedBands[bandIndex].copy(gainDb = clampedGain)
            val updated = current.copy(
                bands = updatedBands,
                selectedPresetName = "Custom",
                isCustomModified = true
            )
            updateState(updated)
        }
    }

    fun resetBand(bandIndex: Int) {
        setBandGain(bandIndex, 0f)
    }

    fun resetAllBands() {
        val current = _uiState.value
        val zeroedBands = current.bands.map { it.copy(gainDb = 0f) }
        val updated = current.copy(
            bands = zeroedBands,
            selectedPresetName = "Flat",
            isCustomModified = false
        )
        updateState(updated)
    }

    fun setMasterGain(gainDb: Float) {
        val current = _uiState.value
        val clamped = gainDb.coerceIn(EqBand.MIN_GAIN_DB, EqBand.MAX_GAIN_DB)
        val updated = current.copy(
            masterGainDb = clamped,
            selectedPresetName = if (current.selectedPresetName in listOf("Flat", "Bass Boost", "Clear", "Voice", "Movie", "Gaming", "Music")) "Custom" else current.selectedPresetName,
            isCustomModified = true
        )
        updateState(updated)
    }

    fun setBassStrength(strength: Float) {
        val current = _uiState.value
        val clamped = strength.coerceIn(0f, 100f)
        val updated = current.copy(
            bassStrength = clamped,
            selectedPresetName = if (current.selectedPresetName != "Custom") "Custom" else current.selectedPresetName,
            isCustomModified = true
        )
        updateState(updated)
    }

    fun setClarityStrength(strength: Float) {
        val current = _uiState.value
        val clamped = strength.coerceIn(0f, 100f)
        val updated = current.copy(
            clarityStrength = clamped,
            selectedPresetName = if (current.selectedPresetName != "Custom") "Custom" else current.selectedPresetName,
            isCustomModified = true
        )
        updateState(updated)
    }

    fun setVoiceStrength(strength: Float) {
        val current = _uiState.value
        val clamped = strength.coerceIn(0f, 100f)
        val updated = current.copy(
            voiceStrength = clamped,
            selectedPresetName = if (current.selectedPresetName != "Custom") "Custom" else current.selectedPresetName,
            isCustomModified = true
        )
        updateState(updated)
    }

    fun setSurroundStrength(strength: Float) {
        val current = _uiState.value
        val clamped = strength.coerceIn(0f, 100f)
        val updated = current.copy(
            surroundStrength = clamped,
            selectedPresetName = if (current.selectedPresetName != "Custom") "Custom" else current.selectedPresetName,
            isCustomModified = true
        )
        updateState(updated)
    }

    fun selectPreset(preset: Preset) {
        val current = _uiState.value
        val updatedBands = current.bands.mapIndexed { index, band ->
            val presetGain = preset.gains.getOrElse(index) { 0f }
            band.copy(gainDb = presetGain)
        }
        val updated = current.copy(
            bands = updatedBands,
            masterGainDb = preset.masterGainDb,
            bassStrength = preset.bassStrength,
            clarityStrength = preset.clarityStrength,
            voiceStrength = preset.voiceStrength,
            surroundStrength = preset.surroundStrength,
            selectedPresetName = preset.name,
            isCustomModified = false
        )
        updateState(updated)
    }

    fun saveCustomPreset(presetName: String) {
        if (presetName.isBlank()) return
        val current = _uiState.value
        val newPreset = Preset(
            name = presetName.trim(),
            isBuiltIn = false,
            gains = current.bands.map { it.gainDb },
            masterGainDb = current.masterGainDb,
            bassStrength = current.bassStrength,
            clarityStrength = current.clarityStrength,
            voiceStrength = current.voiceStrength,
            surroundStrength = current.surroundStrength
        )

        viewModelScope.launch {
            val customs = prefs.customPresetsFlow.first()
            prefs.saveCustomPreset(newPreset, customs)
            val updated = current.copy(
                selectedPresetName = newPreset.name,
                isCustomModified = false
            )
            updateState(updated)
        }
    }

    fun deleteCustomPreset(presetName: String) {
        viewModelScope.launch {
            val customs = prefs.customPresetsFlow.first()
            prefs.deleteCustomPreset(presetName, customs)
            if (_uiState.value.selectedPresetName == presetName) {
                selectPreset(Preset.FLAT)
            }
        }
    }

    fun resetCurrentPreset() {
        val currentName = _uiState.value.selectedPresetName
        val preset = allPresets.value.find { it.name.equals(currentName, ignoreCase = true) }
            ?: Preset.FLAT
        selectPreset(preset)
    }

    fun toggleAutoHeadroom() {
        val current = _uiState.value
        val newAuto = !current.autoHeadroomEnabled
        viewModelScope.launch {
            prefs.setAutoHeadroom(newAuto)
        }
        val updated = current.copy(autoHeadroomEnabled = newAuto)
        updateState(updated)
    }

    fun setBackgroundService(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setBackgroundServiceEnabled(enabled)
            if (enabled) {
                AudioEffectService.startService(
                    getApplication(),
                    _uiState.value.selectedPresetName,
                    _uiState.value.isPowerOn
                )
            } else {
                AudioEffectService.stopService(getApplication())
            }
        }
    }

    fun resetToDefaults() {
        viewModelScope.launch {
            prefs.resetToDefaults()
            selectPreset(Preset.FLAT)
        }
    }

    fun toggleDemoPlayback() {
        demoPlayer.togglePlayback()
    }

    fun selectDemoTrack(track: DemoTrack) {
        demoPlayer.selectTrack(track)
    }

    override fun onCleared() {
        super.onCleared()
        demoPlayer.stop()
    }
}
