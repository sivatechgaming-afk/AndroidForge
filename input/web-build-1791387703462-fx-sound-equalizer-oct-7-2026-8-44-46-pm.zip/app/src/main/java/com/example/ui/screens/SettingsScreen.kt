package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FxAmberSecondary
import com.example.ui.theme.FxBackground
import com.example.ui.theme.FxCyanPrimary
import com.example.ui.theme.FxGreenPower
import com.example.ui.theme.FxOutline
import com.example.ui.theme.FxRedWarning
import com.example.ui.theme.FxSurface
import com.example.ui.theme.FxSurfaceElevated
import com.example.ui.theme.FxSurfaceVariant
import com.example.ui.theme.FxTextMuted
import com.example.ui.theme.FxTextPrimary
import com.example.ui.theme.FxTextSecondary
import com.example.viewmodel.EqualizerViewModel

@Composable
fun SettingsScreen(
    viewModel: EqualizerViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val hardwareInfo by viewModel.hardwareInfo.collectAsState()
    val isBgServiceEnabled by viewModel.isBackgroundServiceEnabled.collectAsState()

    var showResetConfirmDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(FxBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(FxSurfaceVariant)
                            .testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = FxTextPrimary
                        )
                    }

                    Column {
                        Text(
                            text = "Settings & Diagnostics",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = FxTextPrimary
                        )
                        Text(
                            text = "Audio engine diagnostics & configuration",
                            fontSize = 12.sp,
                            color = FxTextSecondary
                        )
                    }
                }
            }

            // 1. HARDWARE AUDIO CAPABILITIES & DIAGNOSTICS
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = FxSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(FxOutline)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = FxCyanPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "DEVICE AUDIO CAPABILITIES",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = FxTextPrimary,
                                letterSpacing = 0.5.sp
                            )
                        }

                        // Equalizer capability
                        CapabilityRow(
                            name = "Hardware Equalizer",
                            status = if (hardwareInfo.equalizerAvailable)
                                "Supported (${hardwareInfo.hardwareBandsCount} physical bands)"
                            else "Unavailable",
                            isSupported = hardwareInfo.equalizerAvailable
                        )

                        // Center frequencies
                        if (hardwareInfo.hardwareCenterFrequenciesHz.isNotEmpty()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "HW Band Frequencies",
                                    fontSize = 12.sp,
                                    color = FxTextSecondary
                                )
                                Text(
                                    text = hardwareInfo.hardwareCenterFrequenciesHz.joinToString(", ") { "$it Hz" },
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = FxCyanPrimary
                                )
                            }
                        }

                        // Equalizer Level Range
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "HW Gain Range",
                                fontSize = 12.sp,
                                color = FxTextSecondary
                            )
                            Text(
                                text = "${hardwareInfo.hardwareLevelRangeDb.first.toInt()} dB to +${hardwareInfo.hardwareLevelRangeDb.second.toInt()} dB",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = FxTextPrimary
                            )
                        }

                        // BassBoost capability
                        CapabilityRow(
                            name = "Android BassBoost",
                            status = if (hardwareInfo.bassBoostAvailable) "Supported (Variable strength)" else "Unsupported (Using EQ Fallback)",
                            isSupported = hardwareInfo.bassBoostAvailable
                        )

                        // Virtualizer capability
                        CapabilityRow(
                            name = "Android Virtualizer (Surround)",
                            status = if (hardwareInfo.virtualizerAvailable) "Supported (Spatial width)" else "Unsupported (Using Phase Fallback)",
                            isSupported = hardwareInfo.virtualizerAvailable
                        )

                        // LoudnessEnhancer capability
                        CapabilityRow(
                            name = "Android LoudnessEnhancer (Master)",
                            status = if (hardwareInfo.loudnessEnhancerAvailable) "Supported (Pre-amp Target Gain)" else "Unsupported (Using Band Offset)",
                            isSupported = hardwareInfo.loudnessEnhancerAvailable
                        )

                        // Active Session ID
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Active Session ID",
                                fontSize = 12.sp,
                                color = FxTextSecondary
                            )
                            Text(
                                text = if (hardwareInfo.isSessionZero) "0 (Global Mix)" else "${hardwareInfo.currentSessionId}",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = FxGreenPower
                            )
                        }
                    }
                }
            }

            // 2. DSP PROCESSING ARCHITECTURE & 20-BAND ENGINE
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = FxSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(FxOutline)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "DSP PROCESSING ARCHITECTURE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = FxTextPrimary,
                            letterSpacing = 0.5.sp
                        )

                        Text(
                            text = "Signal Chain:\nInput Audio → 20-Band Graphic EQ → Bass Processing → Voice Enhancement → Clarity Processing → Surround Spatializer → Master Gain → Output\n\n• Dedicated Effect Stages: Voice, Clarity, Bass, and Surround are independent from your 20 EQ sliders.\n• Output Gain Compensation: Macro controls include automatic loudness compensation so adjusting Voice or Clarity enhances detail without unnaturally boosting master volume.\n• 20-Band Compatibility: Translates your 20 fader levels onto hardware filters using an acoustic Gaussian octave-distance weighting engine for artifact-free sound.",
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            color = FxTextSecondary
                        )
                    }
                }
            }

            // 3. BACKGROUND SERVICE & NOTIFICATION SETTINGS
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = FxSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(FxOutline)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "BACKGROUND AUDIO & PERSISTENCE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = FxTextPrimary,
                            letterSpacing = 0.5.sp
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Foreground Service",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = FxTextPrimary
                                )
                                Text(
                                    text = "Keeps equalizer effects running when the app is minimized with ongoing notification controls.",
                                    fontSize = 12.sp,
                                    color = FxTextSecondary
                                )
                            }
                            Switch(
                                checked = isBgServiceEnabled,
                                onCheckedChange = { viewModel.setBackgroundService(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = FxCyanPrimary,
                                    checkedTrackColor = FxCyanPrimary.copy(alpha = 0.3f)
                                ),
                                modifier = Modifier.testTag("bg_service_switch")
                            )
                        }

                        // Auto-Headroom Limiter
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Anti-Clipping Headroom",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = FxTextPrimary
                                )
                                Text(
                                    text = "Automatically compensates when combined band boosts exceed 6 dB to prevent harsh digital clipping.",
                                    fontSize = 12.sp,
                                    color = FxTextSecondary
                                )
                            }
                            Switch(
                                checked = state.autoHeadroomEnabled,
                                onCheckedChange = { viewModel.toggleAutoHeadroom() },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = FxCyanPrimary,
                                    checkedTrackColor = FxCyanPrimary.copy(alpha = 0.3f)
                                ),
                                modifier = Modifier.testTag("auto_headroom_switch")
                            )
                        }
                    }
                }
            }

            // 4. ANDROID AUDIO ARCHITECTURE & LIMITATIONS
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = FxSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(FxOutline)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "ANDROID AUDIO LIMITATIONS",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = FxTextPrimary,
                            letterSpacing = 0.5.sp
                        )

                        Text(
                            text = "Android audio effect routing is system- and app-dependent:\n• Standard media players broadcasting audio sessions or using the global output mix (Session 0) are processed.\n• Some third-party apps, DRM-protected streams, low-latency game engines, or proprietary OEM Bluetooth stacks may bypass system equalizer effects.\n• You can use the built-in Test Audio Player on the main screen to test and hear the DSP filters on your device anytime.",
                            fontSize = 12.sp,
                            lineHeight = 18.sp,
                            color = FxTextSecondary
                        )
                    }
                }
            }

            // 5. RESTORE DEFAULT SETTINGS
            item {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(FxSurfaceVariant)
                        .border(1.dp, FxOutline, RoundedCornerShape(12.dp))
                        .clickable { showResetConfirmDialog = true }
                        .padding(vertical = 14.dp)
                        .testTag("restore_defaults_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = null,
                            tint = FxAmberSecondary
                        )
                        Text(
                            text = "Restore All Factory Defaults",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = FxAmberSecondary
                        )
                    }
                }
            }

            // Version info
            item {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                ) {
                    Text(
                        text = "FX Sound Equalizer v1.0",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = FxTextMuted
                    )
                    Text(
                        text = "Native Android AudioFX DSP Engine",
                        fontSize = 11.sp,
                        color = FxTextMuted
                    )
                }
            }
        }
    }

    if (showResetConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showResetConfirmDialog = false },
            title = { Text("Restore Defaults", color = FxTextPrimary) },
            text = {
                Text(
                    "Are you sure you want to reset all 20 bands, master gain, bass, clarity, voice, and surround effects to their initial neutral settings?",
                    color = FxTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetToDefaults()
                        showResetConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FxAmberSecondary)
                ) {
                    Text("Reset Everything", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmDialog = false }) {
                    Text("Cancel", color = FxTextSecondary)
                }
            },
            containerColor = FxSurfaceElevated
        )
    }
}

@Composable
private fun CapabilityRow(
    name: String,
    status: String,
    isSupported: Boolean
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = name,
            fontSize = 12.sp,
            color = FxTextSecondary
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = if (isSupported) Icons.Default.CheckCircle else Icons.Default.Error,
                contentDescription = null,
                tint = if (isSupported) FxGreenPower else FxRedWarning,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = status,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = if (isSupported) FxGreenPower else FxRedWarning
            )
        }
    }
}
