package com.example.audio

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.audiofx.AudioEffect
import android.util.Log

/**
 * BroadcastReceiver that listens for Android system audio session events
 * broadcasted by media playback applications.
 */
class AudioSessionReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "AudioSessionReceiver"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent == null) return
        val action = intent.action ?: return
        val sessionId = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, AudioEffect.ERROR_BAD_VALUE)
        val packageName = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME)

        Log.d(TAG, "Received AudioSession broadcast: action=$action, session=$sessionId, pkg=$packageName")

        when (action) {
            AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                if (sessionId != AudioEffect.ERROR_BAD_VALUE && sessionId > 0) {
                    AudioEffectEngine.instance.attachToSession(sessionId, packageName)
                }
            }
            AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                // Return to global output session 0 when the player closes its session
                val currentInfo = AudioEffectEngine.instance.hardwareInfo.value
                if (currentInfo.currentSessionId == sessionId) {
                    Log.d(TAG, "Closing session $sessionId, falling back to global session 0")
                    AudioEffectEngine.instance.attachToSession(0, null)
                }
            }
        }
    }
}
