package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val StudioDarkColorScheme = darkColorScheme(
    primary = FxCyanPrimary,
    onPrimary = FxBackground,
    primaryContainer = FxCyanContainer,
    onPrimaryContainer = FxCyanPrimary,
    secondary = FxAmberSecondary,
    onSecondary = FxBackground,
    secondaryContainer = FxAmberContainer,
    onSecondaryContainer = FxAmberSecondary,
    tertiary = FxPurpleTertiary,
    onTertiary = FxBackground,
    tertiaryContainer = FxPurpleContainer,
    onTertiaryContainer = FxPurpleTertiary,
    background = FxBackground,
    onBackground = FxTextPrimary,
    surface = FxSurface,
    onSurface = FxTextPrimary,
    surfaceVariant = FxSurfaceVariant,
    onSurfaceVariant = FxTextSecondary,
    outline = FxOutline
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            window?.let {
                it.statusBarColor = FxBackground.toArgb()
                it.navigationBarColor = FxBackground.toArgb()
                val controller = WindowCompat.getInsetsController(it, view)
                controller.isAppearanceLightStatusBars = false
                controller.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = StudioDarkColorScheme,
        typography = Typography,
        content = content
    )
}
