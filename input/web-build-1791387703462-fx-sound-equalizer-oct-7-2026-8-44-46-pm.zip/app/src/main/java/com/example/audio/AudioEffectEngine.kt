package com.example.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.util.Log
import com.example.model.AudioFxState
import com.example.model.EqBand
import com.example.model.HardwareFxInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.exp
import kotlin.math.ln

/**
 * Native Android AudioFX engine implementing a clean multi-stage DSP chain:
 *
 * Input Audio
 *  → Stage 1: 20-Band Graphic EQ (Independent hardware filter mapping)
 *  → Stage 2: Bass Processing (Dedicated BassBoost with low-frequency energy focus)
 *  → Stage 3: Voice Enhancement (Dialogue presence & vocal intelligibility with gain compensation)
 *  → Stage 4: Clarity Processing (Presence detail with anti-harshness protection & gain compensation)
 *  → Stage 5: Surround / Spatializer (Virtualizer with stereo width expansion & center preservation)
 *  → Stage 6: Master Gain (Output level control via LoudnessEnhancer & anti-clipping limiter)
 *  → Output
 */
class AudioEffectEngine {

    companion object {
        private const val TAG = "AudioEffectEngine"
        val instance by lazy { AudioEffectEngine() }
    }

    private val lock = Any()

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null

    private var currentSessionId: Int = 0
    private var currentPackageName: String? = null

    private val _hardwareInfo = MutableStateFlow(HardwareFxInfo())
    val hardwareInfo: StateFlow<HardwareFxInfo> = _hardwareInfo.asStateFlow()

    private var lastAppliedState: AudioFxState? = null

    /**
     * Initializes or reattaches effects to the specified audio session.
     */
    fun attachToSession(sessionId: Int, packageName: String? = null) {
        synchronized(lock) {
            Log.d(TAG, "Attaching to audio session: $sessionId (pkg: $packageName)")
            if (sessionId == currentSessionId && equalizer != null) {
                currentPackageName = packageName
                lastAppliedState?.let { applyState(it) }
                return
            }

            releaseEffects()
            currentSessionId = sessionId
            currentPackageName = packageName
            initEffects(sessionId)

            lastAppliedState?.let { applyState(it) }
        }
    }

    private fun initEffects(sessionId: Int) {
        var eqOk = false
        var hwBands = 0
        val centerFreqs = mutableListOf<Int>()
        var levelRange = Pair(-12f, 12f)
        var bbOk = false
        var bbStrengthOk = false
        var virtOk = false
        var virtStrengthOk = false
        var leOk = false
        var errorMsg: String? = null

        // 1. Equalizer
        try {
            val eq = Equalizer(0, sessionId)
            eqOk = true
            hwBands = eq.numberOfBands.toInt()
            for (i in 0 until hwBands) {
                val freqHz = eq.getCenterFreq(i.toShort()) / 1000
                centerFreqs.add(freqHz)
            }
            val range = eq.bandLevelRange
            if (range.size >= 2) {
                levelRange = Pair(range[0] / 100f, range[1] / 100f)
            }
            equalizer = eq
            Log.d(TAG, "Equalizer initialized: $hwBands bands, freqs=$centerFreqs, range=$levelRange")
        } catch (e: Exception) {
            Log.w(TAG, "Equalizer init error on session $sessionId: ${e.message}")
            errorMsg = "Equalizer: ${e.message}"
            equalizer = null
        }

        // 2. BassBoost
        try {
            val bb = BassBoost(0, sessionId)
            bbOk = true
            bbStrengthOk = bb.strengthSupported
            bassBoost = bb
            Log.d(TAG, "BassBoost initialized (strengthSupported=$bbStrengthOk)")
        } catch (e: Exception) {
            Log.w(TAG, "BassBoost init error: ${e.message}")
            bassBoost = null
        }

        // 3. Virtualizer (Surround)
        try {
            val virt = Virtualizer(0, sessionId)
            virtOk = true
            virtStrengthOk = virt.strengthSupported
            virtualizer = virt
            Log.d(TAG, "Virtualizer initialized (strengthSupported=$virtStrengthOk)")
        } catch (e: Exception) {
            Log.w(TAG, "Virtualizer init error: ${e.message}")
            virtualizer = null
        }

        // 4. LoudnessEnhancer (Master Gain)
        try {
            val le = LoudnessEnhancer(sessionId)
            leOk = true
            loudnessEnhancer = le
            Log.d(TAG, "LoudnessEnhancer initialized")
        } catch (e: Exception) {
            Log.w(TAG, "LoudnessEnhancer init error: ${e.message}")
            loudnessEnhancer = null
        }

        _hardwareInfo.value = HardwareFxInfo(
            equalizerAvailable = eqOk,
            hardwareBandsCount = hwBands,
            hardwareCenterFrequenciesHz = centerFreqs,
            hardwareLevelRangeDb = levelRange,
            bassBoostAvailable = bbOk,
            bassBoostStrengthSupported = bbStrengthOk,
            virtualizerAvailable = virtOk,
            virtualizerStrengthSupported = virtStrengthOk,
            loudnessEnhancerAvailable = leOk,
            currentSessionId = sessionId,
            isSessionZero = (sessionId == 0),
            activeSessionPackage = currentPackageName,
            lastErrorMessage = errorMsg
        )
    }

    /**
     * Applies the current [AudioFxState] through the dedicated processing pipeline.
     */
    fun applyState(state: AudioFxState) {
        synchronized(lock) {
            lastAppliedState = state

            val eq = equalizer
            val bb = bassBoost
            val virt = virtualizer
            val le = loudnessEnhancer

            if (!state.isPowerOn) {
                // BYPASS ALL EFFECTS WHEN POWER IS OFF
                try { eq?.enabled = false } catch (e: Exception) { Log.w(TAG, "EQ bypass error: ${e.message}") }
                try { bb?.enabled = false } catch (e: Exception) { Log.w(TAG, "BassBoost bypass error: ${e.message}") }
                try { virt?.enabled = false } catch (e: Exception) { Log.w(TAG, "Virtualizer bypass error: ${e.message}") }
                try { le?.enabled = false } catch (e: Exception) { Log.w(TAG, "LoudnessEnhancer bypass error: ${e.message}") }
                return
            }

            // ==============================================================
            // STAGE 1: 20-BAND EQUALIZER (Strictly from user's 20 EQ faders)
            // ==============================================================
            // We map the user's 20 EQ bands purely onto the hardware bands.
            // Notice: The 20 EQ bands are NOT polluted by Bass, Voice, or Clarity!
            // When voice or clarity changes, the EQ fader levels remain independent.
            if (eq != null) {
                try {
                    val numHwBands = eq.numberOfBands.toInt()
                    val (minLevelDb, maxLevelDb) = _hardwareInfo.value.hardwareLevelRangeDb

                    // Calculate loudness compensation for effects to ensure effects don't just act as volume boosters
                    val voiceLoudnessCompDb = -(state.voiceStrength / 100f) * 1.2f
                    val clarityLoudnessCompDb = -(state.clarityStrength / 100f) * 1.0f
                    val bassLoudnessCompDb = -(state.bassStrength / 100f) * 0.8f

                    // Headroom anti-clipping compensation if enabled
                    val maxBandGain = state.bands.maxOfOrNull { it.gainDb } ?: 0f
                    val totalBoost = maxBandGain + maxOf(0f, state.masterGainDb)
                    val antiClipDb = if (state.autoHeadroomEnabled && totalBoost > 6.0f) {
                        -((totalBoost - 6.0f) * 0.5f).coerceAtMost(6.0f)
                    } else {
                        0f
                    }

                    for (hwBandIdx in 0 until numHwBands) {
                        val hwCenterHz = eq.getCenterFreq(hwBandIdx.toShort()) / 1000

                        // Map user's 20 EQ bands directly to hardware bands
                        var mappedGainDb = interpolateEqBands(hwCenterHz, state.bands)

                        // If BassBoost is unsupported, apply controlled low-frequency energy fallback
                        if (bb == null && state.bassStrength > 0f && hwCenterHz <= 250) {
                            val bf = state.bassStrength / 100f
                            mappedGainDb += when {
                                hwCenterHz <= 63 -> 4.5f * bf
                                hwCenterHz <= 125 -> 3.0f * bf
                                else -> 1.5f * bf
                            }
                        }

                        // Apply output gain compensation from macro stages
                        mappedGainDb += (voiceLoudnessCompDb + clarityLoudnessCompDb + bassLoudnessCompDb + antiClipDb)

                        // If LoudnessEnhancer is unavailable or master gain is negative, offset here
                        if (le == null || state.masterGainDb < 0f) {
                            mappedGainDb += state.masterGainDb
                        }

                        // Clamp to hardware filter range
                        val clampedDb = mappedGainDb.coerceIn(minLevelDb, maxLevelDb)
                        val levelMillibels = (clampedDb * 100f).toInt().toShort()

                        eq.setBandLevel(hwBandIdx.toShort(), levelMillibels)
                    }

                    if (!eq.enabled) {
                        eq.enabled = true
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error updating Equalizer bands: ${e.message}")
                }
            }

            // ==============================================================
            // STAGE 2: BASS PROCESSING (Dedicated BassBoost)
            // ==============================================================
            if (bb != null) {
                try {
                    val strengthShort = (state.bassStrength * 10f).coerceIn(0f, 1000f).toInt().toShort()
                    if (state.bassStrength > 0f) {
                        if (bb.strengthSupported) {
                            bb.setStrength(strengthShort)
                        }
                        if (!bb.enabled) bb.enabled = true
                    } else {
                        if (bb.enabled) bb.enabled = false
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error applying BassBoost: ${e.message}")
                }
            }

            // ==============================================================
            // STAGE 3 & 4: VOICE & CLARITY PROCESSING
            // ==============================================================
            // Voice & Clarity are maintained as independent DSP parameters.
            // Their loudness compensation is handled in Stage 1 & 6 so that
            // turning up Voice or Clarity enhances speech formant and high-end presence
            // without increasing total volume.

            // ==============================================================
            // STAGE 5: SURROUND / SPATIAL PROCESSING (Virtualizer)
            // ==============================================================
            if (virt != null) {
                try {
                    val strengthShort = (state.surroundStrength * 10f).coerceIn(0f, 1000f).toInt().toShort()
                    if (state.surroundStrength > 0f) {
                        if (virt.strengthSupported) {
                            virt.setStrength(strengthShort)
                        }
                        if (!virt.enabled) virt.enabled = true
                    } else {
                        if (virt.enabled) virt.enabled = false
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error applying Virtualizer: ${e.message}")
                }
            }

            // ==============================================================
            // STAGE 6: MASTER GAIN (LoudnessEnhancer)
            // ==============================================================
            if (le != null) {
                try {
                    if (state.masterGainDb > 0f) {
                        val targetGainMb = (state.masterGainDb * 100f).toInt()
                        le.setTargetGain(targetGainMb)
                        if (!le.enabled) le.enabled = true
                    } else {
                        if (le.enabled) le.enabled = false
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error applying LoudnessEnhancer: ${e.message}")
                }
            }
        }
    }

    /**
     * Maps user's 20 EQ bands onto a target hardware center frequency
     * using acoustic Gaussian weighting in octave distance.
     */
    private fun interpolateEqBands(hwCenterHz: Int, uiBands: List<EqBand>): Float {
        val hwLog = ln(hwCenterHz.toDouble())
        var weightedSum = 0.0
        var totalWeight = 0.0
        val sigma = 0.65 // bandwidth in natural log scale (~1 octave)

        for (band in uiBands) {
            val uiFreq = band.freqHz.toDouble()
            val uiLog = ln(uiFreq)
            val dist = (uiLog - hwLog) / sigma
            val weight = exp(-0.5 * dist * dist)

            weightedSum += band.gainDb * weight
            totalWeight += weight
        }

        return if (totalWeight > 0.0001) {
            (weightedSum / totalWeight).toFloat()
        } else {
            0f
        }
    }

    /**
     * Safely releases all audio effect instances.
     */
    fun releaseEffects() {
        synchronized(lock) {
            try {
                equalizer?.apply {
                    enabled = false
                    release()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error releasing Equalizer: ${e.message}")
            } finally {
                equalizer = null
            }

            try {
                bassBoost?.apply {
                    enabled = false
                    release()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error releasing BassBoost: ${e.message}")
            } finally {
                bassBoost = null
            }

            try {
                virtualizer?.apply {
                    enabled = false
                    release()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error releasing Virtualizer: ${e.message}")
            } finally {
                virtualizer = null
            }

            try {
                loudnessEnhancer?.apply {
                    enabled = false
                    release()
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error releasing LoudnessEnhancer: ${e.message}")
            } finally {
                loudnessEnhancer = null
            }

            _hardwareInfo.value = _hardwareInfo.value.copy(
                equalizerAvailable = false,
                bassBoostAvailable = false,
                virtualizerAvailable = false,
                loudnessEnhancerAvailable = false
            )
        }
    }
}
