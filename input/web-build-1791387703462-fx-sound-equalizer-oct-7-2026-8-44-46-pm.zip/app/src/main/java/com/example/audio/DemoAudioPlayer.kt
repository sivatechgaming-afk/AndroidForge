package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

enum class DemoTrack(val title: String, val subtitle: String) {
    BASS_GROOVE("Synth Groove & Beat", "Deep bass, kick, chords & highs (30Hz - 16kHz)"),
    ACOUSTIC_VOCAL("Acoustic & Vocal Sweep", "Warm guitars, dialog formant & ambiance"),
    SPECTRUM_NOISE("Pink Noise Spectrum", "Flat acoustic curve for pure frequency testing")
}

class DemoAudioPlayer {

    companion object {
        private const val TAG = "DemoAudioPlayer"
        private const val SAMPLE_RATE = 44100
        val instance by lazy { DemoAudioPlayer() }
    }

    private var audioTrack: AudioTrack? = null
    private var playbackJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentTrack = MutableStateFlow(DemoTrack.BASS_GROOVE)
    val currentTrack: StateFlow<DemoTrack> = _currentTrack.asStateFlow()

    fun selectTrack(track: DemoTrack) {
        _currentTrack.value = track
    }

    fun togglePlayback() {
        if (_isPlaying.value) {
            stop()
        } else {
            play()
        }
    }

    fun play() {
        if (_isPlaying.value) return

        try {
            val minBufferSize = AudioTrack.getMinBufferSize(
                SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = maxOf(minBufferSize, SAMPLE_RATE / 2)

            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack = track
            track.play()

            val sessionId = track.audioSessionId
            Log.d(TAG, "Started DemoAudioPlayer with session ID: $sessionId")

            // Attach our AudioEffectEngine directly to this player's active session!
            AudioEffectEngine.instance.attachToSession(sessionId, "Internal FX Demo Player")

            _isPlaying.value = true

            playbackJob = scope.launch {
                generateAndStreamAudio(track, bufferSize)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start demo audio player: ${e.message}")
            stop()
        }
    }

    fun stop() {
        _isPlaying.value = false
        playbackJob?.cancel()
        playbackJob = null

        try {
            audioTrack?.apply {
                pause()
                flush()
                stop()
                release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping demo track: ${e.message}")
        } finally {
            audioTrack = null
        }

        // Revert AudioEffectEngine to global session 0
        AudioEffectEngine.instance.attachToSession(0, null)
    }

    private fun generateAndStreamAudio(track: AudioTrack, bufferSize: Int) {
        val numShorts = bufferSize / 2
        val shortBuffer = ShortArray(numShorts)

        var phase = 0.0
        var phaseBass = 0.0
        var phaseChords = 0.0
        var beatCounter = 0
        val bpm = 110
        val samplesPerBeat = (SAMPLE_RATE * 60) / bpm

        var noiseState = 0.0

        while (scope.isActive && _isPlaying.value) {
            val selectedTrack = _currentTrack.value

            for (i in 0 until numShorts step 2) {
                val beatPos = beatCounter % samplesPerBeat
                val barPos = beatCounter % (samplesPerBeat * 4)
                val beatFraction = beatPos.toDouble() / samplesPerBeat

                var leftSample = 0.0
                var rightSample = 0.0

                when (selectedTrack) {
                    DemoTrack.BASS_GROOVE -> {
                        // 1. Kick drum: deep sine sweep from 120Hz down to 45Hz on every beat
                        val kickEnv = kotlin.math.max(0.0, 1.0 - beatFraction * 3.5)
                        val kickFreq = 45.0 + 80.0 * kickEnv
                        phase += 2.0 * PI * kickFreq / SAMPLE_RATE
                        val kick = sin(phase) * kickEnv * 0.45

                        // 2. Bass synth: 55Hz (A1) and 73Hz (D2) with slight drive
                        val bassFreq = if ((barPos / samplesPerBeat) % 2 == 0) 55.0 else 73.4
                        phaseBass += 2.0 * PI * bassFreq / SAMPLE_RATE
                        val bass = (sin(phaseBass) + 0.3 * sin(2.0 * phaseBass)) * 0.28

                        // 3. Chord pad: lush mid harmonies (220Hz, 330Hz, 440Hz, 880Hz)
                        phaseChords += 2.0 * PI * 220.0 / SAMPLE_RATE
                        val pad = (sin(phaseChords) + 0.7 * sin(phaseChords * 1.5) + 0.5 * sin(phaseChords * 2.0)) * 0.12

                        // 4. Hi-hats: crisp white noise clicks on off-beats (8kHz - 16kHz)
                        val hatPos = (beatCounter + samplesPerBeat / 2) % samplesPerBeat
                        val hatEnv = kotlin.math.max(0.0, 1.0 - (hatPos.toDouble() / (SAMPLE_RATE * 0.06)))
                        val noise = ((kotlin.random.Random.nextDouble() * 2.0) - 1.0) * hatEnv * 0.15

                        leftSample = kick + bass + pad * 0.9 + noise * 0.8
                        rightSample = kick + bass + pad * 1.1 + noise * 1.2
                    }

                    DemoTrack.ACOUSTIC_VOCAL -> {
                        // Vocal formant simulation & warm melodic resonance
                        val noteFreq = when ((barPos / (samplesPerBeat / 2)) % 8) {
                            0 -> 261.63 // C4
                            1 -> 329.63 // E4
                            2 -> 392.00 // G4
                            3 -> 523.25 // C5
                            4 -> 440.00 // A4
                            5 -> 349.23 // F4
                            6 -> 392.00 // G4
                            else -> 329.63 // E4
                        }
                        phase += 2.0 * PI * noteFreq / SAMPLE_RATE
                        phaseChords += 2.0 * PI * 130.81 / SAMPLE_RATE // Bass fundamental

                        val tone = sin(phase) * 0.25 + sin(phase * 2.0) * 0.15 + sin(phase * 3.0) * 0.08
                        val subWarmth = sin(phaseChords) * 0.2
                        // Vocal formant resonance (1.5kHz - 2.5kHz)
                        val formant = sin(phase * 5.7) * 0.08

                        leftSample = tone + subWarmth + formant
                        rightSample = tone * 0.95 + subWarmth + formant * 1.05
                    }

                    DemoTrack.SPECTRUM_NOISE -> {
                        // Pink noise approximation (1/f) for full spectrum graphic EQ listening
                        val white = (kotlin.random.Random.nextDouble() * 2.0) - 1.0
                        noiseState = 0.95 * noiseState + 0.05 * white
                        val pink = (noiseState * 3.0 + white * 0.3) * 0.18
                        leftSample = pink
                        rightSample = pink
                    }
                }

                beatCounter++

                // Soft clip limiter to prevent integer overflow
                val clampedL = leftSample.coerceIn(-0.95, 0.95)
                val clampedR = rightSample.coerceIn(-0.95, 0.95)

                shortBuffer[i] = (clampedL * 32767.0).toInt().toShort()
                shortBuffer[i + 1] = (clampedR * 32767.0).toInt().toShort()
            }

            if (track.playState == AudioTrack.PLAYSTATE_PLAYING) {
                track.write(shortBuffer, 0, numShorts)
            }
        }
    }
}
