package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SurroundSound
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EqBand
import com.example.ui.components.DemoPlayerBar
import com.example.ui.components.FaderSlider
import com.example.ui.components.FxCardSlider
import com.example.ui.components.PresetSelector
import com.example.ui.components.SpectrumCurveView
import com.example.ui.theme.FxAmberSecondary
import com.example.ui.theme.FxBackground
import com.example.ui.theme.FxCyanPrimary
import com.example.ui.theme.FxGreenGlow
import com.example.ui.theme.FxGreenPower
import com.example.ui.theme.FxOutline
import com.example.ui.theme.FxOutlineBright
import com.example.ui.theme.FxPurpleTertiary
import com.example.ui.theme.FxRedWarning
import com.example.ui.theme.FxSurface
import com.example.ui.theme.FxSurfaceElevated
import com.example.ui.theme.FxSurfaceVariant
import com.example.ui.theme.FxTextMuted
import com.example.ui.theme.FxTextPrimary
import com.example.ui.theme.FxTextSecondary
import com.example.viewmodel.EqualizerViewModel
import kotlinx.coroutines.launch

@Composable
fun MainEqualizerScreen(
    viewModel: EqualizerViewModel,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val hardwareInfo by viewModel.hardwareInfo.collectAsState()
    val presets by viewModel.allPresets.collectAsState()
    val isPlayingDemo by viewModel.isPlayingDemo.collectAsState()
    val currentDemoTrack by viewModel.currentDemoTrack.collectAsState()

    val faderScrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()

    // Breathing pulse for active Power LED
    val transition = rememberInfiniteTransition(label = "powerPulse")
    val powerGlowAlpha by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse),
        label = "powerGlow"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(FxBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 95.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ==============================================================
            // 1. TOP HEADER & STUDIO POWER SECTION
            // ==============================================================
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "FX SOUND",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = FxTextPrimary,
                                letterSpacing = 1.2.sp
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(FxCyanPrimary.copy(alpha = 0.15f))
                                    .border(0.8.dp, FxCyanPrimary.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "PRO 20-BAND",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FxCyanPrimary,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        // Audio session status readout
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.clickable { onNavigateToSettings() }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (state.isPowerOn) FxGreenPower.copy(alpha = powerGlowAlpha)
                                        else FxTextMuted
                                    )
                            )
                            val sessionDesc = when {
                                !state.isPowerOn -> "Audio Engine Bypassed (Power OFF)"
                                isPlayingDemo -> "Attached: Internal Test Player (Session ${hardwareInfo.currentSessionId})"
                                hardwareInfo.isSessionZero -> "Attached: Global Output Mix (Session 0 • ${hardwareInfo.hardwareBandsCount} HW Bands)"
                                else -> "Attached: Session ${hardwareInfo.currentSessionId} (${hardwareInfo.activeSessionPackage ?: "Media Stream"})"
                            }
                            Text(
                                text = sessionDesc,
                                fontSize = 11.sp,
                                color = if (state.isPowerOn) FxTextSecondary else FxTextMuted,
                                maxLines = 1
                            )
                        }
                    }

                    // Settings & Studio Power Toggle
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = onNavigateToSettings,
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(FxSurfaceVariant)
                                .border(1.dp, FxOutline, RoundedCornerShape(12.dp))
                                .testTag("settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = FxTextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Studio Power Switch with Neon Halo
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(width = 64.dp, height = 42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (state.isPowerOn)
                                        Brush.verticalGradient(
                                            listOf(
                                                FxGreenPower.copy(alpha = 0.25f),
                                                FxSurfaceElevated
                                            )
                                        )
                                    else
                                        Brush.verticalGradient(
                                            listOf(
                                                FxSurfaceVariant,
                                                FxSurface
                                            )
                                        )
                                )
                                .border(
                                    1.2.dp,
                                    if (state.isPowerOn) FxGreenPower else FxOutline,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { viewModel.togglePower() }
                                .testTag("power_switch")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PowerSettingsNew,
                                    contentDescription = if (state.isPowerOn) "Power ON" else "Power OFF",
                                    tint = if (state.isPowerOn) FxGreenPower else FxTextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = if (state.isPowerOn) "ON" else "OFF",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Black,
                                    color = if (state.isPowerOn) FxGreenPower else FxTextMuted
                                )
                            }
                        }
                    }
                }
            }

            // ==============================================================
            // 2. AUDIO SAFETY & ANTI-CLIPPING NOTICE
            // ==============================================================
            item {
                AnimatedVisibility(visible = state.isClippingWarning) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(FxRedWarning.copy(alpha = 0.12f))
                            .border(1.dp, FxRedWarning.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                            .testTag("clipping_warning_card")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Warning",
                                tint = FxRedWarning,
                                modifier = Modifier.size(20.dp)
                            )
                            Column {
                                Text(
                                    text = "High Output Gain Warning",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FxRedWarning
                                )
                                Text(
                                    text = if (state.autoHeadroomEnabled)
                                        "Anti-Clipping Limiter active: attenuating peak boost to protect audio purity."
                                    else
                                        "Combined gains exceed +9 dB. Enable Headroom Limiter in Settings to prevent distortion.",
                                    fontSize = 11.sp,
                                    color = FxTextSecondary
                                )
                            }
                        }
                    }
                }
            }

            // ==============================================================
            // 3. MAIN FOCUS: 20-BAND EQUALIZER CONSOLE (HERO CENTERPIECE)
            // ==============================================================
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = FxSurface),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(FxOutlineBright)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 12.dp)
                    ) {
                        // Console Header
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(FxCyanPrimary.copy(alpha = 0.15f))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Equalizer,
                                        contentDescription = null,
                                        tint = FxCyanPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Column {
                                    Text(
                                        text = "20-BAND GRAPHIC EQUALIZER",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        color = FxTextPrimary,
                                        letterSpacing = 0.8.sp
                                    )
                                    Text(
                                        text = "31 Hz — 16 kHz • -12 dB to +12 dB Precision Faders",
                                        fontSize = 10.sp,
                                        color = FxTextMuted
                                    )
                                }
                            }

                            // Zero All Button
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(FxSurfaceVariant)
                                    .border(1.dp, FxOutline, RoundedCornerShape(8.dp))
                                    .clickable(enabled = state.isPowerOn) { viewModel.resetAllBands() }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                                    .testTag("zero_all_bands_button")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "Zero All",
                                        tint = FxCyanPrimary,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = "Zero All",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = FxTextPrimary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Integrated Top Spectrum Response Visualizer Bridge
                        Box(modifier = Modifier.padding(horizontal = 12.dp)) {
                            SpectrumCurveView(state = state)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick Octave Range Jumper Buttons
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp)
                        ) {
                            RangeJumpPill(
                                label = "ALL (20)",
                                onClick = {
                                    coroutineScope.launch { faderScrollState.animateScrollTo(0) }
                                }
                            )
                            RangeJumpPill(
                                label = "SUB / BASS (31-250Hz)",
                                onClick = {
                                    coroutineScope.launch { faderScrollState.animateScrollTo(0) }
                                }
                            )
                            RangeJumpPill(
                                label = "MIDS (315-1.6k)",
                                onClick = {
                                    coroutineScope.launch { faderScrollState.animateScrollTo(420) }
                                }
                            )
                            RangeJumpPill(
                                label = "HIGHS (2k-16k)",
                                onClick = {
                                    coroutineScope.launch { faderScrollState.animateScrollTo(950) }
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Horizontally Scrollable 20 Faders
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(faderScrollState)
                                .padding(horizontal = 10.dp)
                                .testTag("faders_row")
                        ) {
                            state.bands.forEach { band ->
                                FaderSlider(
                                    band = band,
                                    onGainChanged = { newGain ->
                                        viewModel.setBandGain(band.index, newGain)
                                    },
                                    onReset = {
                                        viewModel.resetBand(band.index)
                                    },
                                    enabled = state.isPowerOn
                                )
                            }
                        }
                    }
                }
            }

            // ==============================================================
            // 4. PRESETS RACK
            // ==============================================================
            item {
                PresetSelector(
                    presets = presets,
                    selectedPresetName = state.selectedPresetName,
                    isCustomModified = state.isCustomModified,
                    onSelectPreset = { viewModel.selectPreset(it) },
                    onSavePreset = { viewModel.saveCustomPreset(it) },
                    onDeletePreset = { viewModel.deleteCustomPreset(it) },
                    onResetCurrentPreset = { viewModel.resetCurrentPreset() },
                    enabled = state.isPowerOn
                )
            }

            // ==============================================================
            // 5. SEPARATE DSP AUDIO PROCESSORS (INDEPENDENT EFFECTS CHAIN)
            // ==============================================================
            item {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "AUDIO PROCESSORS (DSP CHAIN)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = FxTextSecondary,
                            letterSpacing = 0.6.sp
                        )
                        Text(
                            text = "INDEPENDENT FROM EQ",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = FxCyanPrimary
                        )
                    }

                    // 1. MASTER GAIN (-12 dB to +12 dB)
                    FxCardSlider(
                        title = "Master Gain",
                        subtitle = "Overall output pre-amp volume level",
                        dspTag = "PRE-AMP GAIN",
                        value = state.masterGainDb,
                        valueRange = EqBand.MIN_GAIN_DB..EqBand.MAX_GAIN_DB,
                        valueDisplay = when {
                            state.masterGainDb > 0.05f -> "+${"%.1f".format(state.masterGainDb)} dB"
                            state.masterGainDb < -0.05f -> "${"%.1f".format(state.masterGainDb)} dB"
                            else -> "0.0 dB"
                        },
                        accentColor = FxAmberSecondary,
                        icon = Icons.Default.VolumeUp,
                        enabled = state.isPowerOn,
                        onValueChange = { viewModel.setMasterGain(it) },
                        onReset = { viewModel.setMasterGain(0f) },
                        testTagKey = "master_gain"
                    )

                    // 2. BASS (0% to 100%)
                    FxCardSlider(
                        title = "Bass",
                        subtitle = "Low-frequency energy & sub punch",
                        dspTag = "BASSBOOST DSP",
                        value = state.bassStrength,
                        valueRange = 0f..100f,
                        valueDisplay = "${state.bassStrength.toInt()}%",
                        accentColor = FxCyanPrimary,
                        icon = Icons.Default.GraphicEq,
                        enabled = state.isPowerOn,
                        onValueChange = { viewModel.setBassStrength(it) },
                        onReset = { viewModel.setBassStrength(0f) },
                        testTagKey = "bass"
                    )

                    // 3. VOICE (0% to 100%) - Dedicated voice enhancement stage
                    FxCardSlider(
                        title = "Voice",
                        subtitle = "Dialogue presence & speech intelligibility",
                        dspTag = "GAIN COMPENSATED",
                        value = state.voiceStrength,
                        valueRange = 0f..100f,
                        valueDisplay = "${state.voiceStrength.toInt()}%",
                        accentColor = FxAmberSecondary,
                        icon = Icons.Default.Mic,
                        enabled = state.isPowerOn,
                        onValueChange = { viewModel.setVoiceStrength(it) },
                        onReset = { viewModel.setVoiceStrength(0f) },
                        testTagKey = "voice"
                    )

                    // 4. CLARITY (0% to 100%) - Presence detail with anti-harshness protection
                    FxCardSlider(
                        title = "Clarity",
                        subtitle = "High presence detail & anti-harshness filter",
                        dspTag = "GAIN COMPENSATED",
                        value = state.clarityStrength,
                        valueRange = 0f..100f,
                        valueDisplay = "${state.clarityStrength.toInt()}%",
                        accentColor = FxCyanPrimary,
                        icon = Icons.Default.Hearing,
                        enabled = state.isPowerOn,
                        onValueChange = { viewModel.setClarityStrength(it) },
                        onReset = { viewModel.setClarityStrength(0f) },
                        testTagKey = "clarity"
                    )

                    // 5. SURROUND / AMBIENCE (0% to 100%) - Spatial width with center preservation
                    FxCardSlider(
                        title = "Surround / Ambience",
                        subtitle = "3D spatial soundstage & center-preserved width",
                        dspTag = "VIRTUALIZER DSP",
                        value = state.surroundStrength,
                        valueRange = 0f..100f,
                        valueDisplay = "${state.surroundStrength.toInt()}%",
                        accentColor = FxPurpleTertiary,
                        icon = Icons.Default.SurroundSound,
                        enabled = state.isPowerOn,
                        onValueChange = { viewModel.setSurroundStrength(it) },
                        onReset = { viewModel.setSurroundStrength(0f) },
                        testTagKey = "surround"
                    )
                }
            }
        }

        // Docked bottom Demo Audio Player banner
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            DemoPlayerBar(
                isPlaying = isPlayingDemo,
                currentTrack = currentDemoTrack,
                onTogglePlay = { viewModel.toggleDemoPlayback() },
                onSelectTrack = { viewModel.selectDemoTrack(it) }
            )
        }
    }
}

@Composable
private fun RangeJumpPill(
    label: String,
    onClick: () -> Unit
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(FxSurfaceVariant)
            .border(0.8.dp, FxOutline, RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(horizontal = 7.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = FxTextSecondary
        )
    }
}
