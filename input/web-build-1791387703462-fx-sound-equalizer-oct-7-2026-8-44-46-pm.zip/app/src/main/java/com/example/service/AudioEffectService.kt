package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.audio.AudioEffectEngine
import com.example.data.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Foreground service that keeps Android audio effects active in the background
 * and provides persistent notification controls.
 */
class AudioEffectService : Service() {

    companion object {
        const val CHANNEL_ID = "fx_sound_equalizer_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.action.START"
        const val ACTION_STOP = "com.example.action.STOP"
        const val ACTION_TOGGLE_POWER = "com.example.action.TOGGLE_POWER"
        const val ACTION_UPDATE_NOTIFICATION = "com.example.action.UPDATE_NOTIFICATION"

        const val EXTRA_PRESET_NAME = "extra_preset_name"
        const val EXTRA_POWER_STATE = "extra_power_state"

        fun startService(context: Context, presetName: String = "Flat", isPowerOn: Boolean = true) {
            val intent = Intent(context, AudioEffectService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_PRESET_NAME, presetName)
                putExtra(EXTRA_POWER_STATE, isPowerOn)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, AudioEffectService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }

        fun updateNotification(context: Context, presetName: String, isPowerOn: Boolean) {
            val intent = Intent(context, AudioEffectService::class.java).apply {
                action = ACTION_UPDATE_NOTIFICATION
                putExtra(EXTRA_PRESET_NAME, presetName)
                putExtra(EXTRA_POWER_STATE, isPowerOn)
            }
            try {
                context.startService(intent)
            } catch (_: Exception) {
                // If service is not running, ignore
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var currentPreset = "Flat"
    private var isPowerOn = true

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_POWER -> {
                serviceScope.launch {
                    val prefs = PreferencesManager(applicationContext)
                    val currentState = prefs.audioFxStateFlow.first()
                    val newPower = !currentState.isPowerOn
                    prefs.setPowerOn(newPower)
                    val updatedState = currentState.copy(isPowerOn = newPower)
                    AudioEffectEngine.instance.applyState(updatedState)
                    isPowerOn = newPower
                    updateForegroundNotification()
                }
            }
            ACTION_UPDATE_NOTIFICATION -> {
                intent.getStringExtra(EXTRA_PRESET_NAME)?.let { currentPreset = it }
                isPowerOn = intent.getBooleanExtra(EXTRA_POWER_STATE, isPowerOn)
                updateForegroundNotification()
            }
            ACTION_START, null -> {
                intent?.getStringExtra(EXTRA_PRESET_NAME)?.let { currentPreset = it }
                isPowerOn = intent?.getBooleanExtra(EXTRA_POWER_STATE, true) ?: true
                startForeground(NOTIFICATION_ID, buildNotification())
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "FX Sound Equalizer Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps audio effects active in the background"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val togglePowerIntent = Intent(this, AudioEffectService::class.java).apply {
            action = ACTION_TOGGLE_POWER
        }
        val togglePowerPendingIntent = PendingIntent.getService(
            this,
            1,
            togglePowerIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AudioEffectService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val statusText = if (isPowerOn) {
            "FX Active • Preset: $currentPreset"
        } else {
            "FX Bypassed • Power OFF"
        }

        val powerActionTitle = if (isPowerOn) "Bypass / OFF" else "Enable / ON"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FX Sound Equalizer")
            .setContentText(statusText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, powerActionTitle, togglePowerPendingIntent)
            .addAction(0, "Turn Off Service", stopPendingIntent)
            .build()
    }

    private fun updateForegroundNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification())
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
