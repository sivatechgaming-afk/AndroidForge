package com.example.model

/**
 * Representation of an audio preset.
 */
data class Preset(
    val name: String,
    val isBuiltIn: Boolean = true,
    val gains: List<Float>,         // 20 gains corresponding to the 20 bands
    val masterGainDb: Float = 0f,
    val bassStrength: Float = 0f,    // 0..100
    val clarityStrength: Float = 0f, // 0..100
    val voiceStrength: Float = 0f,   // 0..100
    val surroundStrength: Float = 0f // 0..100
) {
    companion object {
        val FLAT = Preset(
            name = "Flat",
            isBuiltIn = true,
            gains = List(20) { 0f },
            masterGainDb = 0f,
            bassStrength = 0f,
            clarityStrength = 0f,
            voiceStrength = 0f,
            surroundStrength = 0f
        )

        val BASS_BOOST = Preset(
            name = "Bass Boost",
            isBuiltIn = true,
            // Low bands 31Hz - 250Hz boosted, smooth curve tapering off
            gains = listOf(
                8.0f, 7.5f, 6.8f, 5.5f, 4.2f,
                3.0f, 2.0f, 1.2f, 0.5f, 0.0f,
                0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
                0.5f, 0.8f, 1.0f, 1.2f, 1.0f
            ),
            masterGainDb = 0f,
            bassStrength = 80f,
            clarityStrength = 15f,
            voiceStrength = 0f,
            surroundStrength = 15f
        )

        val CLEAR = Preset(
            name = "Clear",
            isBuiltIn = true,
            // Highs and upper mids boosted, subs slightly reduced for crisp sound
            gains = listOf(
                -2.0f, -1.8f, -1.5f, -1.0f, -0.5f,
                0.0f, 0.0f, 0.5f, 1.0f, 1.5f,
                2.0f, 2.5f, 3.0f, 4.0f, 5.0f,
                5.5f, 6.0f, 6.5f, 7.0f, 6.0f
            ),
            masterGainDb = 0f,
            bassStrength = 10f,
            clarityStrength = 80f,
            voiceStrength = 20f,
            surroundStrength = 25f
        )

        val VOICE = Preset(
            name = "Voice",
            isBuiltIn = true,
            // 250Hz to 4kHz speech intelligibility peak, subdued rumbles and ultra highs
            gains = listOf(
                -4.5f, -4.0f, -3.5f, -3.0f, -2.0f,
                -1.0f, 0.0f, 0.5f, 1.5f, 2.8f,
                3.8f, 4.5f, 5.0f, 5.5f, 6.0f,
                5.8f, 5.0f, 3.5f, 1.0f, -2.0f
            ),
            masterGainDb = 0.5f,
            bassStrength = 0f,
            clarityStrength = 35f,
            voiceStrength = 85f,
            surroundStrength = 10f
        )

        val MOVIE = Preset(
            name = "Movie",
            isBuiltIn = true,
            // Cinematic dynamic curve: solid low end for explosions, dialog lift, wide surround
            gains = listOf(
                6.0f, 5.5f, 5.0f, 4.0f, 3.0f,
                2.0f, 1.0f, 0.5f, 0.0f, 0.5f,
                1.5f, 2.2f, 2.8f, 3.0f, 3.5f,
                4.0f, 4.5f, 5.0f, 5.2f, 4.5f
            ),
            masterGainDb = 0f,
            bassStrength = 65f,
            clarityStrength = 40f,
            voiceStrength = 45f,
            surroundStrength = 75f
        )

        val GAMING = Preset(
            name = "Gaming",
            isBuiltIn = true,
            // Spatial footsteps clarity and immersive atmosphere
            gains = listOf(
                4.0f, 3.8f, 3.5f, 3.0f, 2.0f,
                1.0f, 0.5f, 0.0f, 0.8f, 1.8f,
                2.5f, 3.2f, 4.0f, 4.8f, 5.5f,
                6.0f, 6.2f, 5.8f, 4.5f, 2.5f
            ),
            masterGainDb = 0.5f,
            bassStrength = 45f,
            clarityStrength = 70f,
            voiceStrength = 30f,
            surroundStrength = 85f
        )

        val MUSIC = Preset(
            name = "Music",
            isBuiltIn = true,
            // Warm, balanced audiophile response
            gains = listOf(
                4.0f, 3.5f, 3.0f, 2.2f, 1.8f,
                1.2f, 0.8f, 0.5f, 0.0f, 0.5f,
                1.0f, 1.5f, 2.0f, 2.8f, 3.2f,
                3.5f, 4.0f, 4.2f, 4.0f, 3.0f
            ),
            masterGainDb = 0f,
            bassStrength = 40f,
            clarityStrength = 45f,
            voiceStrength = 20f,
            surroundStrength = 35f
        )

        val DEFAULT_PRESETS = listOf(
            FLAT, BASS_BOOST, CLEAR, VOICE, MOVIE, GAMING, MUSIC
        )
    }
}
