package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AudioFxState
import com.example.model.EqBand
import com.example.ui.theme.FxAmberSecondary
import com.example.ui.theme.FxCyanPrimary
import com.example.ui.theme.FxOutline
import com.example.ui.theme.FxRedWarning
import com.example.ui.theme.FxSurface
import com.example.ui.theme.FxSurfaceElevated
import com.example.ui.theme.FxSurfaceVariant
import com.example.ui.theme.FxTextMuted
import com.example.ui.theme.FxTextSecondary
import kotlin.math.ln

/**
 * High-precision spectrum response display showing the active 20-band EQ curve.
 */
@Composable
fun SpectrumCurveView(
    state: AudioFxState,
    modifier: Modifier = Modifier
) {
    val minFreqLog = remember { ln(20.0) }
    val maxFreqLog = remember { ln(20000.0) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(FxSurface)
            .border(1.dp, FxOutline.copy(alpha = 0.8f), RoundedCornerShape(14.dp))
            .padding(vertical = 8.dp, horizontal = 12.dp)
            .testTag("spectrum_curve_view")
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            val maxDbRange = 15f
            fun dbToY(db: Float): Float {
                val clamped = db.coerceIn(-maxDbRange, maxDbRange)
                val normalized = (maxDbRange - clamped) / (2 * maxDbRange)
                return normalized * height
            }

            fun freqToX(freqHz: Float): Float {
                val fLog = ln(freqHz.toDouble().coerceIn(20.0, 20000.0))
                val fraction = (fLog - minFreqLog) / (maxFreqLog - minFreqLog)
                return (fraction * width).toFloat()
            }

            // 1. Horizontal dB grid lines
            listOf(-12f, -6f, 0f, 6f, 12f).forEach { db ->
                val y = dbToY(db)
                val isCenter = db == 0f
                drawLine(
                    color = if (isCenter) Color(0x8000E5FF) else FxOutline.copy(alpha = 0.4f),
                    start = Offset(0f, y),
                    end = Offset(width, y),
                    strokeWidth = if (isCenter) 1.5f else 1f
                )
            }

            // 2. Vertical frequency octave lines
            listOf(31f, 100f, 250f, 1000f, 4000f, 16000f).forEach { f ->
                val x = freqToX(f)
                drawLine(
                    color = FxOutline.copy(alpha = 0.35f),
                    start = Offset(x, 0f),
                    end = Offset(x, height),
                    strokeWidth = 1f
                )
            }

            // If power is off, draw a flat bypassed line
            if (!state.isPowerOn) {
                val flatY = dbToY(0f)
                drawLine(
                    color = Color.Gray.copy(alpha = 0.4f),
                    start = Offset(0f, flatY),
                    end = Offset(width, flatY),
                    strokeWidth = 2f,
                    cap = StrokeCap.Round
                )
                return@Canvas
            }

            // 3. Compute points across the user's 20 bands
            val bandPoints = state.bands.map { band ->
                val effectiveDb = band.gainDb
                Offset(freqToX(band.freqHz.toFloat()), dbToY(effectiveDb))
            }

            if (bandPoints.size >= 2) {
                val curvePath = Path().apply {
                    moveTo(0f, bandPoints.first().y)
                    lineTo(bandPoints.first().x, bandPoints.first().y)

                    for (i in 0 until bandPoints.size - 1) {
                        val p0 = bandPoints[i]
                        val p1 = bandPoints[i + 1]
                        val cx = (p0.x + p1.x) / 2f
                        cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
                    }

                    lineTo(width, bandPoints.last().y)
                }

                val fillPath = Path().apply {
                    addPath(curvePath)
                    lineTo(width, height)
                    lineTo(0f, height)
                    close()
                }

                val curveColor = when {
                    state.isClippingWarning -> FxRedWarning
                    else -> FxCyanPrimary
                }

                // Gradient fill underneath curve
                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            curveColor.copy(alpha = 0.4f),
                            curveColor.copy(alpha = 0.08f),
                            Color.Transparent
                        )
                    )
                )

                // Neon curve stroke
                drawPath(
                    path = curvePath,
                    color = curveColor,
                    style = Stroke(width = 2.5f, cap = StrokeCap.Round)
                )

                // Frequency node dots
                bandPoints.forEach { pt ->
                    drawCircle(
                        color = curveColor,
                        radius = 2.8f,
                        center = pt
                    )
                }
            }
        }

        // Overlay labels
        Text(
            text = "+12 dB",
            color = FxTextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.align(Alignment.TopStart)
        )
        Text(
            text = "0 dB",
            color = FxCyanPrimary.copy(alpha = 0.7f),
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.align(Alignment.CenterStart)
        )
        Text(
            text = "-12 dB",
            color = FxTextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.align(Alignment.BottomStart)
        )
        Text(
            text = "20-BAND EQUALIZER RESPONSE (20 Hz — 20 kHz)",
            color = FxTextMuted,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.align(Alignment.BottomEnd)
        )
    }
}
