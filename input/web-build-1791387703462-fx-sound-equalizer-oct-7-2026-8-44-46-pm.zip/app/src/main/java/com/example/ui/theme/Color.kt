package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FxBackground = Color(0xFF090B10)
val FxSurface = Color(0xFF10131C)
val FxSurfaceVariant = Color(0xFF161A26)
val FxSurfaceElevated = Color(0xFF1E2334)
val FxSurfaceGlass = Color(0xD9161A26)
val FxOutline = Color(0xFF282F45)
val FxOutlineBright = Color(0xFF384360)

// Neon Accents
val FxCyanPrimary = Color(0xFF00E5FF)
val FxCyanContainer = Color(0xFF003840)
val FxCyanGlow = Color(0x3300E5FF)

val FxAmberSecondary = Color(0xFFFF9100)
val FxAmberContainer = Color(0xFF3E2200)

val FxPurpleTertiary = Color(0xFF7C4DFF)
val FxPurpleContainer = Color(0xFF24005A)

val FxGreenPower = Color(0xFF00E676)
val FxGreenGlow = Color(0x4D00E676)
val FxRedWarning = Color(0xFFFF5252)

// Frequency Band Octave Colors
val FxBandSub = Color(0xFFFF5722)       // 31 - 80 Hz
val FxBandBass = Color(0xFFFFB300)      // 100 - 250 Hz
val FxBandMid = Color(0xFF00E5FF)       // 315 - 1250 Hz
val FxBandPresence = Color(0xFF9C27B0)  // 1600 - 4000 Hz
val FxBandTreble = Color(0xFF00B0FF)    // 8000 - 16000 Hz

// Text Palette
val FxTextPrimary = Color(0xFFF1F5F9)
val FxTextSecondary = Color(0xFF94A3B8)
val FxTextMuted = Color(0xFF64748B)
