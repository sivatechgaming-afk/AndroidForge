package com.example.model

/**
 * Diagnostics and hardware status regarding Android's AudioEffect capabilities on the current device.
 */
data class HardwareFxInfo(
    val equalizerAvailable: Boolean = false,
    val hardwareBandsCount: Int = 0,
    val hardwareCenterFrequenciesHz: List<Int> = emptyList(),
    val hardwareLevelRangeDb: Pair<Float, Float> = Pair(-12f, 12f),
    val bassBoostAvailable: Boolean = false,
    val bassBoostStrengthSupported: Boolean = false,
    val virtualizerAvailable: Boolean = false,
    val virtualizerStrengthSupported: Boolean = false,
    val loudnessEnhancerAvailable: Boolean = false,
    val currentSessionId: Int = 0,
    val isSessionZero: Boolean = true,
    val activeSessionPackage: String? = null,
    val lastErrorMessage: String? = null
)
