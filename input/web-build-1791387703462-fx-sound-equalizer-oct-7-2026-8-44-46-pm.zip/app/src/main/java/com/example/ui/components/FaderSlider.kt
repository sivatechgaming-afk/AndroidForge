package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EqBand
import com.example.ui.theme.FxAmberSecondary
import com.example.ui.theme.FxBandBass
import com.example.ui.theme.FxBandMid
import com.example.ui.theme.FxBandPresence
import com.example.ui.theme.FxBandSub
import com.example.ui.theme.FxBandTreble
import com.example.ui.theme.FxCyanPrimary
import com.example.ui.theme.FxOutline
import com.example.ui.theme.FxOutlineBright
import com.example.ui.theme.FxRedWarning
import com.example.ui.theme.FxSurface
import com.example.ui.theme.FxSurfaceElevated
import com.example.ui.theme.FxTextMuted
import com.example.ui.theme.FxTextPrimary
import kotlin.math.roundToInt

/**
 * Premium studio rackmount fader for an individual equalizer frequency band.
 */
@Composable
fun FaderSlider(
    band: EqBand,
    onGainChanged: (Float) -> Unit,
    onReset: () -> Unit,
    enabled: Boolean,
    modifier: Modifier = Modifier
) {
    val gain = band.gainDb
    val isBoost = gain > 0.05f
    val isCut = gain < -0.05f

    // Octave group category and accent color
    val (octaveTag, bandColor) = when {
        band.freqHz <= 80 -> "SUB" to FxBandSub
        band.freqHz <= 250 -> "BASS" to FxBandBass
        band.freqHz in 315..1250 -> "MID" to FxBandMid
        band.freqHz in 1600..4000 -> "PRES" to FxBandPresence
        else -> "TREB" to FxBandTreble
    }

    val readoutColor by animateColorAsState(
        targetValue = when {
            !enabled -> FxTextMuted
            gain >= 9.0f -> FxRedWarning
            isBoost -> bandColor
            isCut -> FxAmberSecondary
            else -> FxTextPrimary
        },
        label = "readoutColor"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = modifier
            .width(54.dp)
            .padding(vertical = 4.dp)
            .testTag("fader_${band.freqHz}")
    ) {
        // Octave Tag (e.g. SUB, BASS, MID)
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(if (enabled) bandColor.copy(alpha = 0.15f) else Color.Transparent)
                .padding(horizontal = 4.dp, vertical = 1.dp)
        ) {
            Text(
                text = octaveTag,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = if (enabled) bandColor else FxTextMuted
            )
        }

        // Current Gain Readout
        Text(
            text = band.formattedGain,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = readoutColor,
            maxLines = 1,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        // Tall Vertical Fader Track (Height: 180dp)
        BoxWithConstraints(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .width(46.dp)
                .height(180.dp)
                .padding(vertical = 4.dp)
        ) {
            val trackHeightPx = constraints.maxHeight.toFloat()
            val thumbRadiusPx = 20f
            val usableTravelPx = (trackHeightPx - thumbRadiusPx * 2).coerceAtLeast(1f)

            // Normalized fraction: 0 at +12 dB (top), 1 at -12 dB (bottom)
            val normalized = (EqBand.MAX_GAIN_DB - gain) / (EqBand.MAX_GAIN_DB - EqBand.MIN_GAIN_DB)
            val thumbYOffsetPx = (normalized * usableTravelPx).coerceIn(0f, usableTravelPx)

            // Vertical dragging gesture
            val draggableModifier = if (enabled) {
                Modifier.draggable(
                    orientation = Orientation.Vertical,
                    state = rememberDraggableState { deltaY ->
                        val currentFraction = (EqBand.MAX_GAIN_DB - gain) / (EqBand.MAX_GAIN_DB - EqBand.MIN_GAIN_DB)
                        val deltaFraction = deltaY / usableTravelPx
                        val newFraction = (currentFraction + deltaFraction).coerceIn(0f, 1f)
                        val newGain = EqBand.MAX_GAIN_DB - newFraction * (EqBand.MAX_GAIN_DB - EqBand.MIN_GAIN_DB)
                        val roundedGain = (newGain * 10f).roundToInt() / 10f
                        onGainChanged(roundedGain)
                    }
                )
            } else Modifier

            Box(
                contentAlignment = Alignment.TopCenter,
                modifier = Modifier
                    .fillMaxHeight()
                    .width(46.dp)
                    .then(draggableModifier)
            ) {
                // Background Track Channel
                Box(
                    modifier = Modifier
                        .width(6.dp)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(3.dp))
                        .background(FxSurface)
                        .border(1.dp, FxOutline, RoundedCornerShape(3.dp))
                        .align(Alignment.Center)
                )

                // Illuminated LED Level Column from Center (0 dB) to Thumb
                val centerOffsetPx = usableTravelPx * 0.5f
                val ledHeightPx = kotlin.math.abs(thumbYOffsetPx - centerOffsetPx)
                val ledTopPx = kotlin.math.min(thumbYOffsetPx, centerOffsetPx)

                if (enabled && (isBoost || isCut)) {
                    Box(
                        modifier = Modifier
                            .offset { IntOffset(0, ledTopPx.roundToInt()) }
                            .width(4.dp)
                            .height((ledHeightPx / (trackHeightPx / 180f)).dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        readoutColor.copy(alpha = 0.8f),
                                        readoutColor.copy(alpha = 0.4f)
                                    )
                                )
                            )
                            .align(Alignment.TopCenter)
                    )
                }

                // 0 dB Center Tick Notch
                Box(
                    modifier = Modifier
                        .width(18.dp)
                        .height(2.dp)
                        .background(if (enabled) FxCyanPrimary.copy(alpha = 0.8f) else FxOutline)
                        .align(Alignment.Center)
                )

                // +6 dB Tick Mark
                Box(
                    modifier = Modifier
                        .width(10.dp)
                        .height(1.dp)
                        .background(FxOutline)
                        .align(Alignment.TopCenter)
                        .offset(y = (trackHeightPx * 0.25f / (trackHeightPx / 180f)).dp)
                )

                // -6 dB Tick Mark
                Box(
                    modifier = Modifier
                        .width(10.dp)
                        .height(1.dp)
                        .background(FxOutline)
                        .align(Alignment.TopCenter)
                        .offset(y = (trackHeightPx * 0.75f / (trackHeightPx / 180f)).dp)
                )

                // Tactile Studio Fader Handle Thumb
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .offset { IntOffset(0, thumbYOffsetPx.roundToInt()) }
                        .size(width = 42.dp, height = 24.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    FxSurfaceElevated,
                                    FxSurface,
                                    FxSurfaceElevated
                                )
                            )
                        )
                        .border(
                            1.5.dp,
                            if (enabled && (isBoost || isCut)) readoutColor else FxOutlineBright,
                            RoundedCornerShape(6.dp)
                        )
                ) {
                    // Center Neon Indicator Notch on Thumb
                    Box(
                        modifier = Modifier
                            .width(18.dp)
                            .height(2.5.dp)
                            .clip(RoundedCornerShape(1.dp))
                            .background(if (enabled) readoutColor else FxTextMuted)
                    )
                }
            }
        }

        // Frequency Label
        Text(
            text = band.displayLabel,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (enabled) FxTextPrimary else FxTextMuted,
            maxLines = 1,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        // Discrete "0" Quick Reset Pill
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(width = 38.dp, height = 22.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(if (isBoost || isCut) FxSurfaceElevated else Color.Transparent)
                .border(
                    0.8.dp,
                    if (isBoost || isCut) readoutColor.copy(alpha = 0.5f) else FxOutline.copy(alpha = 0.4f),
                    RoundedCornerShape(4.dp)
                )
                .clickable(enabled = enabled && (isBoost || isCut)) { onReset() }
                .testTag("reset_band_${band.freqHz}")
        ) {
            Text(
                text = "0 dB",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = if (isBoost || isCut) readoutColor else FxTextMuted
            )
        }
    }
}
