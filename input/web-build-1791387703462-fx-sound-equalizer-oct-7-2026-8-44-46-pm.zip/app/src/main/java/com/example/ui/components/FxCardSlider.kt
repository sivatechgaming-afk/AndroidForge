package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.FxOutline
import com.example.ui.theme.FxOutlineBright
import com.example.ui.theme.FxSurface
import com.example.ui.theme.FxSurfaceElevated
import com.example.ui.theme.FxSurfaceVariant
import com.example.ui.theme.FxTextMuted
import com.example.ui.theme.FxTextPrimary
import com.example.ui.theme.FxTextSecondary
import kotlin.math.roundToInt

@Composable
fun FxCardSlider(
    title: String,
    subtitle: String,
    dspTag: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    valueDisplay: String,
    accentColor: Color,
    icon: ImageVector,
    enabled: Boolean,
    onValueChange: (Float) -> Unit,
    onReset: () -> Unit,
    testTagKey: String,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isDragged by interactionSource.collectIsDraggedAsState()
    val animatedScale by animateFloatAsState(
        targetValue = if (isDragged) 1.02f else 1.0f,
        label = "cardScale"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .scale(animatedScale)
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        FxSurfaceVariant,
                        FxSurface
                    )
                )
            )
            .border(
                1.dp,
                if (enabled && isDragged) accentColor.copy(alpha = 0.6f) else FxOutline,
                RoundedCornerShape(14.dp)
            )
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .testTag("fx_card_$testTagKey")
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(accentColor.copy(alpha = 0.15f))
                            .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = if (enabled) accentColor else FxTextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (enabled) FxTextPrimary else FxTextMuted
                            )

                            // DSP Tag badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(accentColor.copy(alpha = 0.12f))
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = dspTag,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = if (enabled) accentColor else FxTextMuted
                                )
                            }
                        }

                        Text(
                            text = subtitle,
                            fontSize = 11.sp,
                            color = FxTextSecondary
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = valueDisplay,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color = if (enabled) accentColor else FxTextMuted
                    )

                    // Reset button
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(FxSurfaceElevated)
                            .border(0.8.dp, FxOutlineBright, RoundedCornerShape(4.dp))
                            .clickable(enabled = enabled) { onReset() }
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                            .testTag("reset_$testTagKey")
                    ) {
                        Text(
                            text = "0",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = if (enabled) FxTextSecondary else FxTextMuted
                        )
                    }
                }
            }

            Slider(
                value = value,
                onValueChange = { newVal ->
                    val rounded = (newVal * 10f).roundToInt() / 10f
                    onValueChange(rounded)
                },
                valueRange = valueRange,
                enabled = enabled,
                interactionSource = interactionSource,
                colors = SliderDefaults.colors(
                    thumbColor = accentColor,
                    activeTrackColor = accentColor,
                    inactiveTrackColor = FxOutline,
                    disabledThumbColor = FxTextMuted,
                    disabledActiveTrackColor = FxTextMuted.copy(alpha = 0.3f),
                    disabledInactiveTrackColor = FxOutline.copy(alpha = 0.2f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("slider_$testTagKey")
            )
        }
    }
}
