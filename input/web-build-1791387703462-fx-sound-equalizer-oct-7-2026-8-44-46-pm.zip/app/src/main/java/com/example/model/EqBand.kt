package com.example.model

/**
 * Model representing an equalizer frequency band.
 * @param index 0-based index in the 20-band list.
 * @param freqHz Center frequency in Hz (e.g., 31, 1000, 16000).
 * @param displayLabel Human-readable label (e.g., "31 Hz", "1 kHz", "16 kHz").
 * @param gainDb Current gain in decibels, typically between -12.0 and +12.0 dB.
 */
data class EqBand(
    val index: Int,
    val freqHz: Int,
    val displayLabel: String,
    val gainDb: Float = 0f
) {
    val formattedGain: String
        get() = when {
            gainDb > 0.05f -> "+${"%.1f".format(gainDb)} dB"
            gainDb < -0.05f -> "${"%.1f".format(gainDb)} dB"
            else -> "0.0 dB"
        }

    companion object {
        const val MIN_GAIN_DB = -12f
        const val MAX_GAIN_DB = 12f

        /**
         * The standard 20 graphic equalizer frequencies as specified.
         */
        val FREQUENCIES = listOf(
            31, 40, 50, 63, 80,
            100, 125, 160, 200, 250,
            315, 400, 500, 630, 800,
            1000, 2000, 4000, 8000, 16000
        )

        fun createDefaultBands(): List<EqBand> {
            return FREQUENCIES.mapIndexed { index, freq ->
                val label = if (freq >= 1000) {
                    "${freq / 1000} kHz"
                } else {
                    "$freq Hz"
                }
                EqBand(
                    index = index,
                    freqHz = freq,
                    displayLabel = label,
                    gainDb = 0f
                )
            }
        }
    }
}
