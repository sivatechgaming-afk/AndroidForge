package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.DemoTrack
import com.example.ui.theme.FxCyanPrimary
import com.example.ui.theme.FxOutline
import com.example.ui.theme.FxSurfaceElevated
import com.example.ui.theme.FxSurfaceVariant
import com.example.ui.theme.FxTextMuted
import com.example.ui.theme.FxTextPrimary
import com.example.ui.theme.FxTextSecondary

@Composable
fun DemoPlayerBar(
    isPlaying: Boolean,
    currentTrack: DemoTrack,
    onTogglePlay: () -> Unit,
    onSelectTrack: (DemoTrack) -> Unit,
    modifier: Modifier = Modifier
) {
    var showTrackMenu by remember { mutableStateOf(false) }

    val transition = rememberInfiniteTransition(label = "pulse")
    val barScale1 by transition.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(400), RepeatMode.Reverse), label = "b1"
    )
    val barScale2 by transition.animateFloat(
        initialValue = 0.8f, targetValue = 0.2f,
        animationSpec = infiniteRepeatable(tween(350), RepeatMode.Reverse), label = "b2"
    )
    val barScale3 by transition.animateFloat(
        initialValue = 0.4f, targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(480), RepeatMode.Reverse), label = "b3"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(FxSurfaceVariant)
            .border(1.dp, if (isPlaying) FxCyanPrimary.copy(alpha = 0.6f) else FxOutline, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("demo_player_bar")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Play / Pause round button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (isPlaying) FxCyanPrimary else FxSurfaceElevated)
                        .border(1.dp, FxCyanPrimary, CircleShape)
                        .clickable { onTogglePlay() }
                        .testTag("demo_player_play_button")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause Test Audio" else "Play Test Audio",
                        tint = if (isPlaying) Color.Black else FxCyanPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column(
                    modifier = Modifier
                        .clickable { showTrackMenu = true }
                        .testTag("demo_track_selector")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = currentTrack.title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = FxTextPrimary
                        )
                        Text(
                            text = "▼",
                            fontSize = 9.sp,
                            color = FxCyanPrimary
                        )
                    }

                    Text(
                        text = if (isPlaying) "Playing Real-time Test Audio • Live Session" else currentTrack.subtitle,
                        fontSize = 11.sp,
                        color = if (isPlaying) FxCyanPrimary else FxTextMuted,
                        maxLines = 1
                    )
                }
            }

            // Animated waveform bars when playing
            if (isPlaying) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier.padding(end = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .height((18 * barScale1).dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(FxCyanPrimary)
                    )
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .height((18 * barScale2).dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(FxCyanPrimary)
                    )
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .height((18 * barScale3).dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(FxCyanPrimary)
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(FxSurfaceElevated)
                        .clickable { onTogglePlay() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "TEST FX",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = FxCyanPrimary
                    )
                }
            }
        }

        // Dropdown menu to pick track
        DropdownMenu(
            expanded = showTrackMenu,
            onDismissRequest = { showTrackMenu = false }
        ) {
            DemoTrack.values().forEach { track ->
                DropdownMenuItem(
                    text = {
                        Column {
                            Text(text = track.title, fontWeight = FontWeight.Bold)
                            Text(text = track.subtitle, fontSize = 11.sp, color = FxTextSecondary)
                        }
                    },
                    onClick = {
                        onSelectTrack(track)
                        showTrackMenu = false
                    }
                )
            }
        }
    }
}
