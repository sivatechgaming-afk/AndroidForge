package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Preset
import com.example.ui.theme.FxAmberSecondary
import com.example.ui.theme.FxCyanPrimary
import com.example.ui.theme.FxOutline
import com.example.ui.theme.FxRedWarning
import com.example.ui.theme.FxSurface
import com.example.ui.theme.FxSurfaceElevated
import com.example.ui.theme.FxSurfaceVariant
import com.example.ui.theme.FxTextMuted
import com.example.ui.theme.FxTextPrimary
import com.example.ui.theme.FxTextSecondary

@Composable
fun PresetSelector(
    presets: List<Preset>,
    selectedPresetName: String,
    isCustomModified: Boolean,
    onSelectPreset: (Preset) -> Unit,
    onSavePreset: (String) -> Unit,
    onDeletePreset: (String) -> Unit,
    onResetCurrentPreset: () -> Unit,
    enabled: Boolean,
    modifier: Modifier = Modifier
) {
    var showSaveDialog by remember { mutableStateOf(false) }
    var newPresetName by remember { mutableStateOf("") }
    var presetToDelete by remember { mutableStateOf<String?>(null) }

    Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "PRESETS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = FxTextSecondary
                )
                if (isCustomModified) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(FxAmberSecondary.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "MODIFIED",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = FxAmberSecondary
                        )
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Reset Preset Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(FxSurfaceVariant)
                        .border(1.dp, FxOutline, RoundedCornerShape(6.dp))
                        .clickable(enabled = enabled) { onResetCurrentPreset() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("reset_preset_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = "Reset Preset",
                            tint = FxTextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Reset",
                            fontSize = 11.sp,
                            color = FxTextSecondary
                        )
                    }
                }

                // Save Preset Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(FxCyanPrimary.copy(alpha = 0.15f))
                        .border(1.dp, FxCyanPrimary.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .clickable(enabled = enabled) {
                            newPresetName = ""
                            showSaveDialog = true
                        }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("save_preset_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Save Preset",
                            tint = FxCyanPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Save",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = FxCyanPrimary
                        )
                    }
                }
            }
        }

        // Horizontal scrolling preset pills
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            presets.forEach { preset ->
                val isSelected = preset.name.equals(selectedPresetName, ignoreCase = true)
                val isCustom = !preset.isBuiltIn

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            when {
                                isSelected -> FxCyanPrimary.copy(alpha = 0.2f)
                                else -> FxSurfaceVariant
                            }
                        )
                        .border(
                            1.dp,
                            when {
                                isSelected -> FxCyanPrimary
                                else -> FxOutline.copy(alpha = 0.6f)
                            },
                            RoundedCornerShape(20.dp)
                        )
                        .clickable(enabled = enabled) { onSelectPreset(preset) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("preset_${preset.name}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = preset.name,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) FxCyanPrimary else FxTextPrimary
                        )

                        // If custom preset, show small delete icon
                        if (isCustom) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(FxRedWarning.copy(alpha = 0.2f))
                                    .clickable { presetToDelete = preset.name }
                                    .testTag("delete_preset_${preset.name}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Delete",
                                    tint = FxRedWarning,
                                    modifier = Modifier.size(12.dp).align(Alignment.Center)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Save Preset Dialog
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = {
                Text(
                    text = "Save Custom Preset",
                    color = FxTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Enter a name for your custom 20-band EQ settings:",
                        fontSize = 13.sp,
                        color = FxTextSecondary
                    )
                    OutlinedTextField(
                        value = newPresetName,
                        onValueChange = { newPresetName = it },
                        placeholder = { Text("e.g., Heavy EDM, Podcast Pro", color = FxTextMuted) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_preset_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPresetName.isNotBlank()) {
                            onSavePreset(newPresetName.trim())
                            showSaveDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FxCyanPrimary)
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Cancel", color = FxTextSecondary)
                }
            },
            containerColor = FxSurfaceElevated
        )
    }

    // Delete Preset Confirmation Dialog
    presetToDelete?.let { name ->
        AlertDialog(
            onDismissRequest = { presetToDelete = null },
            title = { Text("Delete Preset", color = FxTextPrimary) },
            text = { Text("Are you sure you want to delete preset '$name'?", color = FxTextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        onDeletePreset(name)
                        presetToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FxRedWarning)
                ) {
                    Text("Delete", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { presetToDelete = null }) {
                    Text("Cancel", color = FxTextSecondary)
                }
            },
            containerColor = FxSurfaceElevated
        )
    }
}
