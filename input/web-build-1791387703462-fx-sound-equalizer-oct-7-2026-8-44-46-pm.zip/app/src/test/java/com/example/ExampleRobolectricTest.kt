package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.EqBand
import com.example.model.Preset
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("FX Sound Equalizer", appName)
  }

  @Test
  fun `verify twenty bands created with correct frequencies`() {
    val bands = EqBand.createDefaultBands()
    assertEquals(20, bands.size)
    assertEquals(31, bands[0].freqHz)
    assertEquals(16000, bands[19].freqHz)
  }

  @Test
  fun `verify default presets contain 20 bands`() {
    Preset.DEFAULT_PRESETS.forEach { preset ->
      assertEquals("Preset ${preset.name} must have 20 gains", 20, preset.gains.size)
    }
  }

  @Test
  fun `verify changing voice and bass does not modify twenty eq band positions`() {
    val initialBands = EqBand.createDefaultBands()
    val state = com.example.model.AudioFxState(
      bands = initialBands,
      voiceStrength = 75f,
      bassStrength = 80f,
      clarityStrength = 60f,
      surroundStrength = 50f
    )
    // The 20 bands remain strictly independent
    assertEquals(20, state.bands.size)
    state.bands.forEachIndexed { index, band ->
      assertEquals("Band $index must remain unchanged", initialBands[index].gainDb, band.gainDb, 0.001f)
    }
  }
}
